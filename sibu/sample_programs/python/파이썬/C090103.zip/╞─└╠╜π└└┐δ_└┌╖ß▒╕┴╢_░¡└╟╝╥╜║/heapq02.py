import heapq

from showHeap import show_tree
from heapData import data

heapq.heapify(data)
show_tree(data)
