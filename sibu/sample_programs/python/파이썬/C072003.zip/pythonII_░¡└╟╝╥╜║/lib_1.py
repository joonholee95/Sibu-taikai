# pickle모듈: 객체 형태를 그대로 유지해서 파일에 저장 시키고, 불러올 수 있게 하는 모듈이다.
#				  바이너리 형태로 저장한다.
# Pickle이용해서 파일에 저장 및 조회할 때는 꼭 바이너리 처리를 해야한다. b를 입력해서
# 바이너리라는 것을 표시해야 한다.
# 저장시 pickle.dump(objet, file), 불러올때는 pickle.load(file)
# pickle.dumps(object)  ---->string 
# pickle.loads(String) ---->object


