for aa in [100,200,300]:
	print (aa)
