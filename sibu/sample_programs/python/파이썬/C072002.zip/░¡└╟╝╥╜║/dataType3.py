''' 5) 불린형(참과 거짓)

		문자열 : "aaa" ---> 참(true), ""(false)
		리스트 : [1,22,33] 참, [](거짓)
		튜플 : ('a','b')참, ()거짓
		딕셔너리 : {}(거짓)
		숫자 : 1(참), 0(거짓)
		None (거짓)
'''

if []:
	print("참")
else:
	print("거짓")

if [1,2]:
	print("true")
else:
	print("false")
